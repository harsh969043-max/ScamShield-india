# ScamShield India — Hackathon MVP

AI-assisted digital scam and phishing-risk screening prototype. It combines a small TF-IDF + Logistic Regression text classifier with explainable pattern-based rules.

## Included features

- Analyze message, email, URL, and phone-related scam context
- 0–100 heuristic risk score and LOW / MEDIUM / HIGH category
- Rule-based reason labels and recommended safety action
- SQLite scan history and dashboard statistics
- FastAPI REST API and interactive `/docs`
- Local model; optional VirusTotal URL reputation lookup (API key required)
- Docker support

## Windows setup

Use Python 3.12 if available (the Docker image uses Python 3.12).

```powershell
# Open the extracted project folder in VS Code, then run:
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python train_model.py
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000`. API docs: `http://127.0.0.1:8000/docs`.

If `py -3.12` is not installed, use a Python version compatible with the pinned dependencies, then create a fresh virtual environment.

## Optional URL reputation scanner (VirusTotal)

URL mode can query VirusTotal for an existing reputation report. It does **not** open or fetch the submitted website. Without an API key, local URL heuristics continue to work and the UI says the external lookup is not configured.

1. Create/sign in to a VirusTotal account and obtain an API key from your account profile.
2. Set the key in the same PowerShell terminal before starting the server:

```powershell
$env:VIRUSTOTAL_API_KEY="PASTE_YOUR_API_KEY_HERE"
uvicorn app.main:app --reload
```

Keep the key private: do not paste it into frontend JavaScript, commit it to Git, or share screenshots containing it. Free API plans have rate limits and terms. The URL is sent to VirusTotal for lookup, so do not submit private/internal URLs or URLs containing personal tokens. A URL with no report is **unknown**, not confirmed safe. A clean result does not guarantee safety.

The integration only looks up an existing report; it does not automatically submit new URLs for scanning. When VirusTotal reports malicious detections, the project raises the risk score; suspicious detections also raise the score. This is a prototype heuristic and should be validated before real-world use.

## API

- `GET /api/health` — service status and whether the model loaded
- `POST /api/analyze` — analyze text or URL
- `GET /api/history?limit=50` — recent scans (limit 1–100)
- `GET /api/stats` — scan counts by risk level
- `GET /docs` — interactive API documentation

Example request:

```json
{
  "input_type": "message",
  "content": "URGENT bank KYC expired. Share OTP immediately at http://bit.ly/test"
}
```

Supported `input_type` values: `message`, `email`, `url`, `phone`. URL mode expects a single complete URL or domain, e.g. `https://example.com` or `example.com`.

## How the risk score works

The current prototype adds configured rule weights and a bounded model contribution, then caps the result at 100:

- Rule weights are defined in `app/engine.py` under `PATTERNS` and `url_indicators`.
- Model contribution: `round(model_estimated_scam_probability * 35)`, when the model is available.
- `0–39`: LOW
- `40–69`: MEDIUM
- `70–100`: HIGH

The score is a **heuristic risk score**, not a calibrated probability of real-world fraud. A low score does not prove that a URL or message is safe. These thresholds and weights are starting values for a prototype and should be tuned against a representative, labeled test set.

## Important limitations

- The included model is trained on a small, hand-written demonstration dataset in `train_model.py`. It is suitable for demonstrating the workflow, **not for claiming production or national-scale accuracy**.
- Before a real deployment, train and evaluate with a representative, lawfully obtained dataset and a held-out test set. Report precision, recall, F1-score, confusion matrix, and false-negative rate.
- The app does not visit submitted URLs. Optional VirusTotal reputation lookup checks existing reports without fetching the target website. Without an API key or existing report, URL indicators remain heuristic and cannot establish whether a site is truly malicious.
- Scan history currently stores submitted content in a local SQLite database. Do not use real passwords, OTPs, payment data, or private messages in demos. A deployed version should define retention, access control, and deletion policies.
- This tool provides advisory results and can make mistakes. Verify unexpected requests through official channels.

## Test

From the project root, after installing dependencies:

```powershell
python -m pytest -q
```

## National hackathon checklist

1. Demonstrate the complete flow from input to result.
2. Explain the actual scoring weights and thresholds above.
3. Be transparent that the bundled training dataset is a demo dataset.
4. Show measured evaluation results only after running a proper held-out evaluation.
5. Keep future ideas such as QR analysis, browser extension, and SMS dataset-based detection labelled as planned unless implemented and tested.
