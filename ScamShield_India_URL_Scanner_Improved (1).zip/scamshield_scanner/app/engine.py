from pathlib import Path
import ipaddress
import re
from urllib.parse import urlparse

import joblib

from .reputation import check_url_reputation

MODEL_PATH = Path(__file__).resolve().parent.parent / "models" / "scamshield_text_model.joblib"
try:
    MODEL = joblib.load(MODEL_PATH) if MODEL_PATH.exists() else None
except Exception:
    # Keep the API available so /api/health can report that the model is unavailable.
    MODEL = None

PATTERNS = {
    "OTP / credential request": (12, [r"\botp\b", r"one time password", r"\bcvv\b", r"\bpin\b", r"\bpassword\b"]),
    "Urgency / threat": (10, [r"\burgent\b", r"\bimmediately\b", r"\btoday\b", r"within \d+", r"account.*block", r"\bdisconnect\b"]),
    "Payment request": (14, [r"\bpay\b", r"\bpayment\b", r"send money", r"processing fee", r"advance fee", r"registration fee"]),
    "KYC / identity bait": (12, [r"\bkyc\b", r"\baadhaar\b", r"\bpan card\b", r"verify.*account", r"\breactivate\b"]),
    "Prize / reward bait": (12, [r"\bwon\b", r"\bwinner\b", r"\blottery\b", r"\breward\b", r"\bgift\b", r"\biphone\b"]),
    "Guaranteed returns": (12, [r"\bguaranteed\b", r"double.*money", r"risk.?free", r"guaranteed returns"]),
    "Authority impersonation": (10, [r"\bpolice\b", r"cyber cell", r"income tax", r"\bgovernment\b", r"\bcourt\b", r"arrest warrant"]),
    "Remote-access request": (10, [r"remote access", r"\banydesk\b", r"\bteamviewer\b", r"screen sharing"]),
}

SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy", "shorturl.at"}


def _extract_urls(text: str):
    # Include http(s), www, and common bare-domain forms without fetching them.
    candidates = re.findall(
        r"(?:https?://|www\.)[^\s<>]+|(?<![@\w.-])(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}(?::\d{1,5})?(?:/[^\s<>]*)?",
        text,
        flags=re.I,
    )
    out = []
    for raw in candidates:
        candidate = raw.rstrip(".,!?;:)]}\"'")
        if candidate and candidate not in out:
            out.append(candidate)
    return out


def url_indicators(text: str):
    findings = []
    for raw in _extract_urls(text):
        candidate = raw if "://" in raw else "http://" + raw
        try:
            parsed = urlparse(candidate)
            host = (parsed.hostname or "").lower().rstrip(".")
            if not host:
                continue
            if host in SHORTENERS:
                findings.append(("Shortened URL", 12))
            if "@" in parsed.netloc:
                findings.append(("URL contains deceptive @ syntax", 15))
            try:
                ipaddress.ip_address(host)
                findings.append(("URL uses an IP address", 15))
            except ValueError:
                pass
            if host.count("-") >= 3 or len(host.split(".")) > 4:
                findings.append(("Unusual domain structure", 8))
            if parsed.scheme == "http":
                findings.append(("Unencrypted HTTP link", 5))
        except ValueError:
            findings.append(("Malformed URL syntax", 8))
    return findings


def _validate_url_input(text: str):
    candidate = text.strip()
    if not candidate:
        raise ValueError("Enter a URL to analyze.")
    if any(ch.isspace() for ch in candidate):
        raise ValueError("For URL mode, enter one URL without spaces.")
    parsed = urlparse(candidate if "://" in candidate else "https://" + candidate)
    if parsed.scheme.lower() not in {"http", "https"}:
        raise ValueError("Only http and https URLs are supported.")
    if not parsed.hostname or "." not in parsed.hostname:
        raise ValueError("Enter a complete URL, such as https://example.com.")
    try:
        parsed.port  # Accessing port validates malformed port values.
    except ValueError as exc:
        raise ValueError("The URL contains an invalid port.") from exc


def analyze(text: str, kind: str = "message"):
    if kind not in {"message", "email", "url", "phone"}:
        raise ValueError("Unsupported input type.")
    if not isinstance(text, str):
        raise ValueError("Input must be text.")
    clean = re.sub(r"\s+", " ", text.strip().lower())
    if not clean:
        raise ValueError("Input cannot be empty")
    if kind == "url":
        _validate_url_input(clean)

    reasons = []
    score = 0

    for label, (weight, regexes) in PATTERNS.items():
        if any(re.search(rx, clean) for rx in regexes):
            reasons.append(label)
            score += weight

    for label, weight in url_indicators(clean):
        if label not in reasons:
            reasons.append(label)
            score += weight

    ml_probability = None
    if MODEL is not None:
        try:
            # The training script labels scam as 1 and legitimate as 0.
            classes = list(MODEL.classes_)
            scam_index = classes.index(1)
            ml_probability = float(MODEL.predict_proba([clean])[0][scam_index])
            # Keep the model contribution explicit and bounded. This is a heuristic
            # risk score, not a calibrated probability of real-world fraud.
            model_points = round(ml_probability * 35)
            score += model_points
            if ml_probability >= 0.65:
                reasons.append("ML model found scam-like text patterns")
        except (AttributeError, ValueError, IndexError):
            ml_probability = None

    if kind == "phone" and re.search(r"(?:\+91|91)?[6-9]\d{9}", clean):
        if any(x in clean for x in ["otp", "kyc", "pay", "loan", "prize"]):
            reasons.append("Phone-number scam context")
            score += 10

    reputation = None
    if kind == "url":
        # Optional lookup against known URL reports. We never fetch the submitted site.
        normalized_url = text.strip()
        if "://" not in normalized_url:
            normalized_url = "https://" + normalized_url
        reputation = check_url_reputation(normalized_url)
        if reputation.get("status") == "malicious":
            score = max(score, 85)
            reasons.append(reputation["message"])
        elif reputation.get("status") == "suspicious":
            score = max(score, 55)
            reasons.append(reputation["message"])
        # Lookup status is returned separately so an unavailable/unlisted URL is
        # not incorrectly treated as a suspicious indicator by itself.

    score = min(100, max(0, score))
    if score >= 70:
        level = "HIGH"
    elif score >= 40:
        level = "MEDIUM"
    else:
        level = "LOW"

    if not reasons:
        reasons = ["No strong scam indicators detected by the current model/rules"]

    mapping = {
        "OTP / credential request": "OTP / Credential Scam",
        "KYC / identity bait": "KYC Scam",
        "Payment request": "Payment / UPI Scam",
        "Prize / reward bait": "Prize / Reward Scam",
        "Guaranteed returns": "Investment Scam",
        "Authority impersonation": "Impersonation Scam",
        "Remote-access request": "Tech Support Scam",
        "Urgency / threat": "Social Engineering",
    }
    categories = []
    for reason in reasons:
        if reason in mapping and mapping[reason] not in categories:
            categories.append(mapping[reason])
    if not categories:
        categories = ["General suspicious content"]

    if level == "HIGH":
        action = "Do not click links, share OTP/PIN/CVV, transfer money, or install remote-access software. Verify independently using the organization's official channel."
    elif level == "MEDIUM":
        action = "Pause before acting. Verify the sender, domain and request through an official channel before sharing information or making a payment."
    else:
        action = "No strong indicators were detected. This is not proof that the content is safe; verify unexpected requests independently."

    return {
        "risk_score": score,
        "risk_level": level,
        "categories": categories,
        "reasons": reasons,
        "recommended_action": action,
        "model_probability": round(ml_probability, 4) if ml_probability is not None else None,
        "model_probability_note": "Model-estimated scam-text probability; not a guarantee of real-world fraud.",
        "engine": "TF-IDF + Logistic Regression + security rule engine" + (" + VirusTotal reputation lookup" if kind == "url" else ""),
        "reputation": reputation,
    }
