from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from .engine import analyze
from .db import init_db, add_scan, history, stats

ROOT = Path(__file__).resolve().parent.parent
STATIC_DIR = ROOT / "static"

app = FastAPI(
    title="ScamShield India API",
    version="1.1.0",
    description="AI-assisted scam detection and citizen safety API",
)

# Same-origin use is preferred. These origins are permitted for local development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:8000",
        "http://localhost:8000",
        "http://127.0.0.1:5500",
        "http://localhost:5500",
        "http://127.0.0.1:5173",
        "http://localhost:5173",
    ],
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


class ScanRequest(BaseModel):
    input_type: str = Field(default="message", pattern="^(message|email|url|phone)$")
    content: str = Field(min_length=3, max_length=10000)

    @field_validator("content")
    @classmethod
    def content_must_not_be_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Content cannot be blank")
        return value.strip()


@app.on_event("startup")
def startup():
    init_db()


@app.get("/")
def home():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
def health():
    from .engine import MODEL
    return {
        "status": "ok",
        "service": "ScamShield India",
        "model_loaded": MODEL is not None,
        "model": "TF-IDF + Logistic Regression" if MODEL is not None else None,
    }


@app.post("/api/analyze")
def scan(req: ScanRequest):
    try:
        result = analyze(req.content, req.input_type)
        scan_id = add_scan(req.input_type, req.content, result)
        return {"scan_id": scan_id, **result}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        # Do not expose internal stack traces or file paths to API clients.
        raise HTTPException(
            status_code=500,
            detail="Analysis could not be completed. Please try again.",
        ) from exc


@app.get("/api/history")
def get_history(limit: int = Query(default=50, ge=1, le=100)):
    return {"items": history(limit)}


@app.get("/api/stats")
def get_stats():
    return stats()
