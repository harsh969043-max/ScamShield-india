import sqlite3
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "scamshield.db"
DB_PATH.parent.mkdir(exist_ok=True)

def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    with conn() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            input_type TEXT NOT NULL,
            content TEXT NOT NULL,
            risk_score INTEGER NOT NULL,
            risk_level TEXT NOT NULL,
            categories TEXT NOT NULL,
            reasons TEXT NOT NULL,
            created_at TEXT NOT NULL
        )''')

def add_scan(input_type, content, result):
    import json
    with conn() as c:
        cur = c.execute('INSERT INTO scans(input_type,content,risk_score,risk_level,categories,reasons,created_at) VALUES(?,?,?,?,?,?,?)',
            (input_type, content, result['risk_score'], result['risk_level'], json.dumps(result['categories']), json.dumps(result['reasons']), datetime.now(timezone.utc).isoformat()))
        return cur.lastrowid

def history(limit=50):
    import json
    with conn() as c:
        rows = c.execute('SELECT * FROM scans ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
    return [{**dict(r), 'categories': json.loads(r['categories']), 'reasons': json.loads(r['reasons'])} for r in rows]

def stats():
    with conn() as c:
        total = c.execute('SELECT COUNT(*) n FROM scans').fetchone()['n']
        high = c.execute("SELECT COUNT(*) n FROM scans WHERE risk_level='HIGH'").fetchone()['n']
        medium = c.execute("SELECT COUNT(*) n FROM scans WHERE risk_level='MEDIUM'").fetchone()['n']
        low = c.execute("SELECT COUNT(*) n FROM scans WHERE risk_level='LOW'").fetchone()['n']
    return {'total_scans': total, 'high_risk': high, 'medium_risk': medium, 'low_risk': low}
