"""Optional third-party URL reputation lookup.

Only sends the URL to VirusTotal's API endpoint; the backend never opens/fetches
that URL. Configure VIRUSTOTAL_API_KEY to enable this feature.
"""
import base64
import os

import requests

VT_URL = "https://www.virustotal.com/api/v3/urls/{}"


def check_url_reputation(url: str) -> dict:
    api_key = os.getenv("VIRUSTOTAL_API_KEY", "").strip()
    if not api_key:
        return {
            "provider": "VirusTotal",
            "status": "not_configured",
            "message": "Threat-intelligence lookup is not configured. Add VIRUSTOTAL_API_KEY to enable it.",
            "malicious": None,
            "suspicious": None,
            "harmless": None,
            "undetected": None,
            "permalink": None,
        }

    # VirusTotal identifies a URL using URL-safe Base64 without '=' padding.
    url_id = base64.urlsafe_b64encode(url.encode("utf-8")).decode("ascii").strip("=")
    try:
        response = requests.get(
            VT_URL.format(url_id),
            headers={"x-apikey": api_key},
            timeout=8,
        )
        if response.status_code == 404:
            return {
                "provider": "VirusTotal",
                "status": "not_found",
                "message": "This URL has no existing VirusTotal report. It is not confirmed safe.",
                "malicious": 0,
                "suspicious": 0,
                "harmless": 0,
                "undetected": 0,
                "permalink": None,
            }
        if response.status_code == 401:
            return {
                "provider": "VirusTotal", "status": "configuration_error",
                "message": "VirusTotal rejected the API key. Check VIRUSTOTAL_API_KEY.",
                "malicious": None, "suspicious": None, "harmless": None,
                "undetected": None, "permalink": None,
            }
        if response.status_code == 429:
            return {
                "provider": "VirusTotal", "status": "rate_limited",
                "message": "VirusTotal rate limit reached. Try again later.",
                "malicious": None, "suspicious": None, "harmless": None,
                "undetected": None, "permalink": None,
            }
        response.raise_for_status()
        payload = response.json()
        attributes = payload.get("data", {}).get("attributes", {})
        stats = attributes.get("last_analysis_stats", {})
        malicious = int(stats.get("malicious", 0))
        suspicious = int(stats.get("suspicious", 0))
        harmless = int(stats.get("harmless", 0))
        undetected = int(stats.get("undetected", 0))
        if malicious > 0:
            status = "malicious"
            message = f"VirusTotal reports {malicious} malicious detection(s)."
        elif suspicious > 0:
            status = "suspicious"
            message = f"VirusTotal reports {suspicious} suspicious detection(s)."
        else:
            status = "no_malicious_detections"
            message = "No malicious detections were reported in the available VirusTotal results; this does not prove the URL is safe."
        return {
            "provider": "VirusTotal",
            "status": status,
            "message": message,
            "malicious": malicious,
            "suspicious": suspicious,
            "harmless": harmless,
            "undetected": undetected,
            "permalink": None,
        }
    except requests.Timeout:
        return {
            "provider": "VirusTotal", "status": "unavailable",
            "message": "VirusTotal lookup timed out; local analysis was used.",
            "malicious": None, "suspicious": None, "harmless": None,
            "undetected": None, "permalink": None,
        }
    except requests.RequestException:
        return {
            "provider": "VirusTotal", "status": "unavailable",
            "message": "VirusTotal lookup failed; local analysis was used.",
            "malicious": None, "suspicious": None, "harmless": None,
            "undetected": None, "permalink": None,
        }
    except (TypeError, ValueError):
        return {
            "provider": "VirusTotal", "status": "invalid_response",
            "message": "VirusTotal returned an unreadable response; local analysis was used.",
            "malicious": None, "suspicious": None, "harmless": None,
            "undetected": None, "permalink": None,
        }
