let inputType = "message";
const $ = (id) => document.getElementById(id);

document.querySelectorAll(".tabs button").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".tabs button").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    inputType = button.dataset.type;
    $("content").placeholder = inputType === "url"
      ? "Enter one URL, for example https://example.com"
      : "Paste a suspicious message, email, URL or phone-related request here...";
  });
});

$("sample").addEventListener("click", () => {
  $("content").value = "URGENT: Your bank KYC has expired. Your account will be blocked today. Verify immediately at http://bit.ly/bank-kyc and share your OTP to reactivate.";
});

$("analyze").addEventListener("click", async () => {
  const content = $("content").value.trim();
  if (!content) {
    showNotice("Paste some content first.", true);
    return;
  }

  const button = $("analyze");
  button.disabled = true;
  button.textContent = "Analyzing...";
  hideNotice();

  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ input_type: inputType, content })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.detail || "Analysis failed. Please try again.");
    }
    renderResult(data);
    await Promise.all([loadStats(), loadHistory()]);
  } catch (error) {
    showNotice(error.message || "Could not connect to the backend. Check that the server is running.", true);
  } finally {
    button.disabled = false;
    button.textContent = "Analyze with ScamShield →";
  }
});

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
  })[character]);
}

function renderResult(data) {
  const level = ["low", "medium", "high"].includes(String(data.risk_level).toLowerCase())
    ? String(data.risk_level).toLowerCase()
    : "medium";
  const score = Math.max(0, Math.min(100, Number(data.risk_score) || 0));
  const categories = Array.isArray(data.categories) ? data.categories : [];
  const reasons = Array.isArray(data.reasons) ? data.reasons : [];
  const probability = Number.isFinite(Number(data.model_probability))
    ? `${(Number(data.model_probability) * 100).toFixed(1)}%`
    : "N/A";
  const reputation = data.reputation;
  const reputationHtml = reputation ? `
    <div class="action">
      <b>Threat-intelligence check (${escapeHtml(reputation.provider || "External provider")})</b><br>
      ${escapeHtml(reputation.message || "No reputation result available.")}
      ${reputation.malicious !== null && reputation.malicious !== undefined
        ? `<br><span class="muted">Malicious: ${escapeHtml(reputation.malicious)} · Suspicious: ${escapeHtml(reputation.suspicious)} · Harmless: ${escapeHtml(reputation.harmless)} · Undetected: ${escapeHtml(reputation.undetected)}</span>`
        : ""}
    </div>` : "";

  $("result").className = "result";
  $("result").innerHTML = `
    <div class="result-head">
      <div>
        <span class="eyebrow">SCAN #${escapeHtml(data.scan_id)}</span>
        <div class="risk ${level}">${escapeHtml(level.toUpperCase())} RISK</div>
      </div>
      <div style="text-align:right">
        <strong style="font-size:34px">${score}<small>/100</small></strong>
        <div class="muted">risk score</div>
      </div>
    </div>
    <div class="bar"><i style="width:${score}%"></i></div>
    <p><b>Categories:</b> ${categories.map(escapeHtml).join(" · ") || "Not classified"}</p>
    <p><b>Why:</b></p>
    <ul>${reasons.map((reason) => `<li>${escapeHtml(reason)}</li>`).join("")}</ul>
    ${reputationHtml}
    <div class="action"><b>Recommended action</b><br>${escapeHtml(data.recommended_action)}</div>
    <p class="muted">Model-estimated scam-text probability: ${probability}. This is not a guarantee of real-world fraud. · ${escapeHtml(data.engine)}</p>`;
}

function showNotice(message, isError = false) {
  let notice = $("notice");
  if (!notice) {
    notice = document.createElement("p");
    notice.id = "notice";
    notice.setAttribute("role", "status");
    $("scanner").appendChild(notice);
  }
  notice.className = isError ? "notice error" : "notice";
  notice.textContent = message;
}
function hideNotice() {
  const notice = $("notice");
  if (notice) notice.textContent = "";
}

async function loadStats() {
  try {
    const response = await fetch("/api/stats");
    if (!response.ok) throw new Error("Stats unavailable");
    const data = await response.json();
    $("total").textContent = data.total_scans ?? 0;
    $("high").textContent = data.high_risk ?? 0;
    $("medium").textContent = data.medium_risk ?? 0;
    $("low").textContent = data.low_risk ?? 0;
  } catch (_) {
    // Keep the interface usable if statistics are temporarily unavailable.
  }
}

async function loadHistory() {
  try {
    const response = await fetch("/api/history");
    if (!response.ok) throw new Error("History unavailable");
    const data = await response.json();
    if (!Array.isArray(data.items) || !data.items.length) {
      $("historyList").innerHTML = '<p class="muted">No scans yet.</p>';
      return;
    }
    $("historyList").innerHTML = data.items.map((item) => {
      const level = ["low", "medium", "high"].includes(String(item.risk_level).toLowerCase())
        ? String(item.risk_level).toLowerCase() : "medium";
      return `<div class="history-item">
        <span class="badge ${level}">${escapeHtml(level.toUpperCase())}</span>
        <p>${escapeHtml(item.content)}</p>
        <span class="muted">${Math.max(0, Math.min(100, Number(item.risk_score) || 0))}/100</span>
      </div>`;
    }).join("");
  } catch (_) {
    $("historyList").innerHTML = '<p class="muted">Scan history is temporarily unavailable.</p>';
  }
}

loadStats();
loadHistory();
