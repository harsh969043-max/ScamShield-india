from pathlib import Path
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

DATA = {
    "scam": [
        "urgent your bank account will be blocked verify kyc immediately click link",
        "congratulations you won lottery pay processing fee to receive prize",
        "your upi account is suspended share otp to reactivate now",
        "parcel delivery failed pay rs 25 using this link",
        "work from home job earn 50000 registration fee required",
        "investment guaranteed double money crypto trading send payment",
        "income tax refund claim click link and enter pan otp",
        "police cyber cell arrest warrant pay fine immediately",
        "kyc expired update bank details password otp through this link",
        "electricity connection disconnect today pay bill through unknown link",
        "customer care asks for remote access and otp",
        "your sim card will deactivate verify aadhaar now",
        "you have won iphone pay courier charges",
        "account security alert login verify password card cvv",
        "scholarship approved pay small verification fee",
        "credit card reward points expire redeem via link",
        "refund pending click link enter card details and otp",
        "loan approved pay advance fee to release amount",
        "investment opportunity guaranteed returns send us money",
        "friend emergency send money to this new upi id",
    ],
    "legitimate": [
        "your monthly bank statement is available in the official banking app",
        "your order has been shipped you can track it from the official website",
        "the university has published the semester timetable on the student portal",
        "your electricity bill is available in the official customer portal",
        "meeting reminder for tomorrow at ten am in conference room",
        "your flight booking confirmation is available in the airline app",
        "please find the project report attached for review",
        "your account statement can be downloaded after signing into the official app",
        "the college library will remain open until eight pm today",
        "your appointment is confirmed for monday at eleven am",
        "the delivery partner will attempt delivery tomorrow",
        "your monthly subscription payment was successful",
        "please update your profile from the official website if needed",
        "the examination form submission deadline is friday",
        "your internship interview is scheduled for monday",
        "the scholarship application status is available on the university portal",
        "the bank branch will be closed on the public holiday",
        "your train ticket confirmation is available in the railway app",
        "the company has published its annual report",
        "please contact support through the official website for assistance",
    ],
}

def main():
    texts = DATA["scam"] + DATA["legitimate"]
    labels = [1]*len(DATA["scam"]) + [0]*len(DATA["legitimate"])
    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1,2), sublinear_tf=True, min_df=1)),
        ("clf", LogisticRegression(max_iter=1500, class_weight="balanced")),
    ])
    pipe.fit(texts, labels)
    out = Path("models/scamshield_text_model.joblib")
    out.parent.mkdir(exist_ok=True)
    joblib.dump(pipe, out)
    print(f"Saved {out}")

if __name__ == "__main__":
    main()
