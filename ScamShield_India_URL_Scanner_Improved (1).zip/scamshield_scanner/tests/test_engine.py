from app.engine import analyze


def test_scam_message_is_high_risk():
    result = analyze(
        "URGENT bank KYC expired, share OTP and pay verification fee at http://bit.ly/test"
    )
    assert result["risk_level"] == "HIGH"
    assert result["risk_score"] >= 70
    assert result["reasons"]


def test_normal_message_does_not_crash():
    result = analyze("Your university has published the semester timetable on the student portal.")
    assert 0 <= result["risk_score"] <= 100
    assert result["risk_level"] in {"LOW", "MEDIUM", "HIGH"}


def test_url_mode_rejects_sentence():
    try:
        analyze("please check this for me", "url")
    except ValueError as exc:
        assert "URL" in str(exc) or "url" in str(exc).lower()
    else:
        raise AssertionError("URL mode should reject non-URL input")


def test_url_mode_accepts_domain():
    result = analyze("https://example.com", "url")
    assert result["risk_level"] in {"LOW", "MEDIUM", "HIGH"}


def test_bare_shortened_url_is_flagged():
    result = analyze("Please visit bit.ly/test for details")
    assert "Shortened URL" in result["reasons"]


def test_blank_content_rejected():
    try:
        analyze("   ")
    except ValueError as exc:
        assert "empty" in str(exc).lower()
    else:
        raise AssertionError("Blank content should be rejected")


def test_url_scan_returns_reputation_status():
    result = analyze("https://example.com", "url")
    assert "reputation" in result
    assert result["reputation"]["provider"] == "VirusTotal"
    assert result["reputation"]["status"] in {
        "not_configured", "not_found", "malicious", "suspicious",
        "no_malicious_detections", "configuration_error", "rate_limited",
        "unavailable", "invalid_response"
    }
