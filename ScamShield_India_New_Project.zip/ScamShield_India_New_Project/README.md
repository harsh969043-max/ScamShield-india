# ScamShield India — New Hackathon Project

A local-first hackathon demo built with Python, FastAPI, SQLite, HTML, CSS and JavaScript.

## Features
- Explainable scam triage for suspicious messages, URLs, phone numbers and UPI-related text.
- QR scanning in supported desktop browsers using the camera or an uploaded image (uses `jsQR` CDN).
- Spam-number warning list and a manual blocklist view.
- Complaint registration for 16 scam categories.
- Complaint history lookup using the contact phone number.
- Downloadable PDF complaint record with reference ID.
- SQLite database created automatically under `data/`.

## Requirements
- Windows 10/11
- Python 3.10+ (Python 3.14 may work; if dependency installation fails, install Python 3.12 or 3.13)
- Internet connection the first time to install packages and load the QR library CDN.

## Run in VS Code
1. Extract this ZIP.
2. Open the extracted `ScamShield_India_New_Project` folder in VS Code.
3. Open a terminal in that folder.
4. Run `run_windows.bat`, or use:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   .\.venv\Scripts\python.exe -m uvicorn main:app --reload
   ```
5. Open `http://127.0.0.1:8000` in Chrome/Edge.
6. API docs: `http://127.0.0.1:8000/docs`

If PowerShell blocks activation, the instructions above use the venv Python directly and do not require activation.

## Important limitations
- Scanner results are rule-based demonstration signals, not a trained ML model, live reputation lookup, or a guarantee of safety.
- Browser QR scanning depends on camera permission and a supported browser; image scanning uses a third-party JavaScript library loaded from jsDelivr.
- A website cannot silently block phone calls on a user's device. This project stores and displays a warning/blocklist. Real automatic call blocking requires a native Android app and the appropriate OS permissions/default caller-ID role.
- PDF complaints are saved ScamShield demo records, not official police/cybercrime filings. For India, users should promptly contact their bank/payment provider and use 1930 / cybercrime.gov.in for financial cyber fraud.
- This demo has no login or identity verification. Do not deploy publicly with real sensitive personal data without authentication, access controls, encryption, retention rules and security review.
