const $ = (id) => document.getElementById(id);
let scanKind = "text";
const labels = {text:"Paste suspicious message",url:"Paste suspicious URL",upi:"Enter UPI ID or payment-related text",phone:"Enter suspicious phone number"};
document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(b=>b.classList.remove("active"));
  btn.classList.add("active"); scanKind=btn.dataset.kind;
  $("scanLabel").textContent=labels[scanKind]; $("scanInput").placeholder=labels[scanKind];
}));
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
async function api(url, options={}) {
  const res=await fetch(url,{headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  const data=await res.json().catch(()=>({detail:"Unexpected server response"}));
  if(!res.ok) throw new Error(data.detail||"Request failed");
  return data;
}
function showError(el,msg){el.classList.remove("hidden");el.className="result risk-high";el.innerHTML=`<h3>Something went wrong</h3><p>${esc(msg)}</p>`;}
$("scanBtn").addEventListener("click", async()=>{
  const value=$("scanInput").value.trim(); const out=$("scanResult");
  if(!value){showError(out,"Enter a message, URL, UPI ID or phone number first.");return;}
  out.classList.remove("hidden");out.className="result";out.innerHTML="<p>Analysing...</p>";
  try{const r=await api("/api/scan",{method:"POST",body:JSON.stringify({kind:scanKind,value})});
    const cls=r.risk_level.toLowerCase();out.className=`result risk-${cls}`;
    out.innerHTML=`<span class="risk-pill ${cls}">${esc(r.risk_level)} RISK · ${r.risk_score}/100</span><h3 style="margin-top:12px">${esc(r.title)}</h3><p>Signals found in the submitted content:</p><ul>${r.reasons.map(x=>`<li>${esc(x)}</li>`).join("")}</ul><p><b>Next step:</b> Do not click, pay, approve a collect request or share secrets until independently verified.</p><small>${esc(r.disclaimer)}</small>`;
  }catch(e){showError(out,e.message);}
});
$("clearScan").addEventListener("click",()=>{$("scanInput").value="";$("scanResult").classList.add("hidden");});
const categories=["UPI / Payment Fraud","Fake QR Code / Payment Request","Phishing Website / URL","SMS / Email Scam","Fake Customer Care","Bank / Card Fraud","Investment / Crypto Scam","Job / Work-from-Home Scam","Online Shopping Fraud","Social Media / Impersonation","Loan App Scam","Digital Arrest / Government Impersonation","Lottery / Prize Scam","Romance Scam","Identity Theft","Other / Unknown"];
$("scamType").innerHTML='<option value="">Select category</option>'+categories.map(c=>`<option>${esc(c)}</option>`).join("");

async function loadNumbers(){
 const box=$("numbersList");
 try{const r=await api("/api/flagged-numbers");if(!r.numbers.length){box.innerHTML='<p class="muted">No numbers saved yet.</p>';return;}
 box.innerHTML=r.numbers.map(n=>`<div class="list-item"><div><strong>${esc(n.phone)} · ${esc(n.label||"Suspected spam")}</strong><small>${esc(n.reason||"No reason supplied")}<br>Added ${esc(n.created_at)}</small></div><button class="small-btn" data-remove="${esc(n.phone)}">Remove</button></div>`).join("");
 box.querySelectorAll("[data-remove]").forEach(b=>b.onclick=async()=>{try{await api("/api/flagged-numbers/"+encodeURIComponent(b.dataset.remove),{method:"DELETE"});loadNumbers();}catch(e){alert(e.message)}});
 }catch(e){box.innerHTML=`<p class="muted">${esc(e.message)}</p>`;}
}
$("numberForm").addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/flagged-numbers",{method:"POST",body:JSON.stringify({phone:$("flagPhone").value,label:"Suspected spam",reason:$("flagReason").value})});$("flagPhone").value="";$("flagReason").value="";loadNumbers();}catch(err){alert(err.message)}});
loadNumbers();

$("complaintForm").addEventListener("submit",async e=>{
 e.preventDefault();const out=$("complaintResult");out.classList.remove("hidden");out.className="result";out.innerHTML="<p>Saving report...</p>";
 const payload={full_name:$("fullName").value.trim(),phone:$("contactPhone").value.trim(),email:$("email").value.trim(),scam_type:$("scamType").value,incident_date:$("incidentDate").value,amount:Number($("amount").value||0),channel:$("channel").value.trim(),suspect_detail:$("suspectDetail").value.trim(),description:$("description").value.trim(),transaction_id:$("transactionId").value.trim(),evidence_notes:$("evidence").value.trim()};
 try{const r=await api("/api/complaints",{method:"POST",body:JSON.stringify(payload)});
 out.className="result risk-low";out.innerHTML=`<span class="risk-pill low">REPORT SAVED</span><h3 style="margin-top:12px">Reference: ${esc(r.reference)}</h3><p>${esc(r.notice)}</p><p>Keep this reference number. You can download the report now or retrieve it later using your contact phone.</p><a class="btn primary" href="${esc(r.pdf_url)}" target="_blank" rel="noopener">Download complaint PDF ↓</a>`;
 $("historyPhone").value=payload.phone;
 }catch(err){showError(out,err.message)}
});
$("historyForm").addEventListener("submit",async e=>{
 e.preventDefault();const box=$("historyResults");box.innerHTML="<p class='muted'>Searching...</p>";
 try{const r=await api("/api/complaints?phone="+encodeURIComponent($("historyPhone").value.trim()));
 if(!r.complaints.length){box.innerHTML='<p class="muted">No reports found for this phone number.</p>';return;}
 box.innerHTML=r.complaints.map(c=>`<div class="list-item"><div><strong>${esc(c.reference)} · ${esc(c.scam_type)}</strong><small>${esc(c.created_at)} · ${esc(c.status)}</small></div><a class="small-btn" href="/api/complaints/${encodeURIComponent(c.reference)}/pdf" target="_blank" rel="noopener">Download PDF</a></div>`).join("");
 }catch(err){box.innerHTML=`<p class="muted">${esc(err.message)}</p>`}
});

let stream=null, scanTimer=null;
function stopCamera(){if(scanTimer)cancelAnimationFrame(scanTimer);scanTimer=null;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;$("qrVideo").classList.add("hidden");}
$("stopCamera").addEventListener("click",stopCamera);
async function decodeImage(img){
 if(!window.jsQR){$("qrStatus").textContent="QR library did not load. Check internet connection and reload.";return;}
 const canvas=$("qrCanvas"),ctx=canvas.getContext("2d",{willReadFrequently:true});
 canvas.width=img.naturalWidth||img.videoWidth;canvas.height=img.naturalHeight||img.videoHeight;ctx.drawImage(img,0,0,canvas.width,canvas.height);
 const data=ctx.getImageData(0,0,canvas.width,canvas.height);const code=jsQR(data.data,data.width,data.height);
 if(!code){$("qrStatus").textContent="No QR code detected. Try a clearer, well-lit image.";return;}
 $("qrStatus").textContent="QR decoded. Sending its contents to the scanner; do not open or pay until verified.";
 scanKind=/^https?:\/\//i.test(code.data)?"url":(/^[\w.\-+]+@[\w.-]+$/.test(code.data)?"upi":"qr");
 $("scanInput").value=code.data;
 document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.kind===scanKind));
 $("scanLabel").textContent=scanKind==="url"?labels.url:(scanKind==="upi"?labels.upi:"Decoded QR contents");
 $("scanInput").scrollIntoView({behavior:"smooth",block:"center"});
 $("scanBtn").click();
}
$("qrFile").addEventListener("change",e=>{
 const file=e.target.files[0];if(!file)return;
 const img=new Image();img.onload=()=>decodeImage(img);img.onerror=()=>$("qrStatus").textContent="Could not read that image.";
 img.src=URL.createObjectURL(file);
});
$("startCamera").addEventListener("click",async()=>{
 if(!navigator.mediaDevices?.getUserMedia){$("qrStatus").textContent="Camera scanning is not supported in this browser/context. Use image upload.";return;}
 try{stopCamera();stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"}});const video=$("qrVideo");video.srcObject=stream;video.classList.remove("hidden");await video.play();
 const tick=()=>{if(!stream)return;if(video.readyState===video.HAVE_ENOUGH_DATA&&window.jsQR){const canvas=$("qrCanvas"),ctx=canvas.getContext("2d",{willReadFrequently:true});canvas.width=video.videoWidth;canvas.height=video.videoHeight;ctx.drawImage(video,0,0,canvas.width,canvas.height);const d=ctx.getImageData(0,0,canvas.width,canvas.height);const code=jsQR(d.data,d.width,d.height);if(code){const img=new Image();img.onload=()=>{stopCamera();decodeImage(img)};img.src=canvas.toDataURL();return;}}scanTimer=requestAnimationFrame(tick);};
 $("qrStatus").textContent="Point the camera at a QR code. Camera access stays in this browser.";tick();
 }catch(e){$("qrStatus").textContent="Camera permission denied or unavailable. Try uploading a QR image instead.";}
});
