from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Optional, List
from pathlib import Path
from datetime import datetime, timezone
import sqlite3, re, uuid, os
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import mm

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
PDF_DIR = DATA_DIR / "complaint_pdfs"
DATA_DIR.mkdir(exist_ok=True)
PDF_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "scamshield.db"

app = FastAPI(title="ScamShield India", version="1.0.0",
              description="Hackathon demo: explainable scam triage and complaint records.")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

SCAM_TYPES = [
    "UPI / Payment Fraud", "Fake QR Code / Payment Request", "Phishing Website / URL",
    "SMS / Email Scam", "Fake Customer Care", "Bank / Card Fraud",
    "Investment / Crypto Scam", "Job / Work-from-Home Scam", "Online Shopping Fraud",
    "Social Media / Impersonation", "Loan App Scam", "Digital Arrest / Government Impersonation",
    "Lottery / Prize Scam", "Romance Scam", "Identity Theft", "Other / Unknown"
]

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS complaints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reference TEXT UNIQUE NOT NULL, created_at TEXT NOT NULL,
            full_name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT,
            scam_type TEXT NOT NULL, incident_date TEXT, amount REAL,
            channel TEXT, suspect_detail TEXT, description TEXT NOT NULL,
            transaction_id TEXT, evidence_notes TEXT, status TEXT NOT NULL DEFAULT 'Saved in ScamShield'
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS flagged_numbers (
            id INTEGER PRIMARY KEY AUTOINCREMENT, phone TEXT UNIQUE NOT NULL,
            label TEXT, reason TEXT, created_at TEXT NOT NULL
        )""")
init_db()

class ScanRequest(BaseModel):
    kind: str = "text"
    value: str = Field(min_length=1, max_length=10000)

class ComplaintIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=100)
    phone: str = Field(min_length=7, max_length=20)
    email: Optional[str] = Field(default="", max_length=120)
    scam_type: str
    incident_date: Optional[str] = ""
    amount: Optional[float] = Field(default=0, ge=0, le=100000000000)
    channel: Optional[str] = ""
    suspect_detail: Optional[str] = ""
    description: str = Field(min_length=10, max_length=5000)
    transaction_id: Optional[str] = ""
    evidence_notes: Optional[str] = ""

class FlagNumberIn(BaseModel):
    phone: str = Field(min_length=7, max_length=20)
    label: Optional[str] = "Suspected spam"
    reason: Optional[str] = ""

def scan_value(kind: str, value: str):
    v = value.strip()
    low = v.lower()
    reasons = []
    score = 5
    patterns = [
        (r'\b(otp|one.time password)\b', 25, "Mentions an OTP; never share OTPs with callers or messages."),
        (r'\b(urgent|immediately|within \d+ minutes|account.*(block|suspend))\b', 18, "Uses urgency or account-suspension pressure."),
        (r'\b(upi pin|pin to receive|enter your pin|share your pin)\b', 28, "Suggests sharing/entering a UPI PIN to receive money. A PIN should not be needed to receive money."),
        (r'\b(collect request|approve.*request|request money)\b', 18, "May be asking you to approve a payment/collect request."),
        (r'\b(prize|lottery|won.*(cash|reward)|claim.*reward)\b', 15, "Unexpected prize/reward claims are a common scam pattern."),
        (r'\b(kyc|verify.*account|pan.*blocked|aadhaar.*blocked)\b', 12, "Account/KYC threat or verification pressure."),
        (r'\b(remote access|anydesk|screen sharing|install.*app)\b', 22, "Requests remote access or screen sharing."),
        (r'\b(guaranteed return|double your money|risk.free profit)\b', 22, "Promises unusually high or guaranteed returns."),
        (r'\b(police|cbi|customs|digital arrest|arrest warrant)\b', 20, "May impersonate law enforcement or threaten arrest."),
        (r'\b(bit\.ly|tinyurl\.com|t\.co|is\.gd|cutt\.ly)\b', 12, "Contains a URL-shortening service that hides the final destination."),
        (r'\b(password|cvv|card number|bank details)\b', 12, "Requests sensitive account or card information."),
    ]
    for pattern, points, explanation in patterns:
        if re.search(pattern, low):
            score += points
            reasons.append(explanation)
    urls = re.findall(r'https?://[^\s<>"\']+|www\.[^\s<>"\']+', v, re.I)
    for url in urls:
        host = url.lower().replace("https://", "").replace("http://", "").replace("www.", "").split("/")[0]
        if "@" in host:
            score += 25
            reasons.append("URL contains an @ symbol in its host portion; inspect it carefully.")
        if re.match(r'^\d{1,3}(?:\.\d{1,3}){3}$', host):
            score += 25
            reasons.append("URL uses a raw IP address instead of a recognizable domain.")
        if host.count("-") >= 3:
            score += 10
            reasons.append("Domain contains several hyphens, which can be suspicious.")
        if host.endswith((".zip", ".top", ".xyz", ".click", ".work")):
            score += 8
            reasons.append("Domain ending may deserve extra scrutiny; this alone does not prove fraud.")
    if kind == "phone":
        digits = re.sub(r"\D", "", v)
        if len(digits) < 10:
            reasons.append("Number format may be incomplete; verify it before acting.")
        if len(set(digits)) <= 2 and len(digits) >= 8:
            score += 12
            reasons.append("Number has a repetitive digit pattern.")
    if kind == "upi":
        if "@" not in v:
            reasons.append("This does not look like a typical UPI ID; verify with your payment app.")
        if re.search(r'\b(pin|otp|password)\b', low):
            score += 20
            reasons.append("Sensitive authentication terms appear in the submitted UPI-related text.")
    score = min(score, 100)
    if score >= 60:
        level, title = "HIGH", "High-risk indicators found"
    elif score >= 30:
        level, title = "MEDIUM", "Some suspicious indicators found"
    else:
        level, title = "LOW", "Few known indicators found"
    if not reasons:
        reasons = ["No matching demo rules were triggered. This is not proof that the item is safe."]
    return {"risk_score": score, "risk_level": level, "title": title, "reasons": reasons,
            "checked_kind": kind, "checked_at": datetime.now().astimezone().isoformat(),
            "disclaimer": "Demo rule-based screening, not a guarantee or official verification. Do not send money or disclose OTP/PIN based only on this result."}

@app.get("/", response_class=HTMLResponse)
def home():
    return FileResponse(ROOT / "static" / "index.html")

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "ScamShield India", "version": "1.0.0"}

@app.post("/api/scan")
def scan(payload: ScanRequest):
    allowed = {"text", "url", "phone", "upi", "qr"}
    if payload.kind not in allowed:
        raise HTTPException(400, "Unsupported scan type.")
    return scan_value(payload.kind, payload.value)

@app.get("/api/complaints")
def list_complaints(phone: str):
    with db() as conn:
        rows = conn.execute("SELECT reference, created_at, scam_type, status FROM complaints WHERE phone=? ORDER BY id DESC", (phone,)).fetchall()
    return {"complaints": [dict(r) for r in rows]}

@app.post("/api/complaints")
def create_complaint(payload: ComplaintIn):
    if payload.scam_type not in SCAM_TYPES:
        raise HTTPException(400, "Choose a valid scam category.")
    ref = "SSI-" + datetime.now().strftime("%y%m%d") + "-" + uuid.uuid4().hex[:6].upper()
    created = datetime.now().astimezone().isoformat(timespec="seconds")
    fields = payload.model_dump()
    with db() as conn:
        conn.execute("""INSERT INTO complaints
        (reference,created_at,full_name,phone,email,scam_type,incident_date,amount,channel,suspect_detail,description,transaction_id,evidence_notes,status)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (ref, created, fields["full_name"], fields["phone"], fields.get("email",""), fields["scam_type"],
         fields.get("incident_date",""), fields.get("amount",0), fields.get("channel",""),
         fields.get("suspect_detail",""), fields["description"], fields.get("transaction_id",""),
         fields.get("evidence_notes",""), "Saved in ScamShield"))
    return {"reference": ref, "created_at": created, "status": "Saved in ScamShield",
            "pdf_url": f"/api/complaints/{ref}/pdf",
            "notice": "This is a ScamShield demo record, not an official police/cybercrime complaint."}

@app.get("/api/complaints/{reference}/pdf")
def complaint_pdf(reference: str):
    with db() as conn:
        row = conn.execute("SELECT * FROM complaints WHERE reference=?", (reference,)).fetchone()
    if not row:
        raise HTTPException(404, "Complaint reference not found.")
    out = PDF_DIR / f"{reference}.pdf"
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="CenterTitle", parent=styles["Title"], alignment=TA_CENTER, textColor=colors.HexColor("#12345a")))
    styles.add(ParagraphStyle(name="Small", parent=styles["BodyText"], fontSize=8, leading=10))
    doc = SimpleDocTemplate(str(out), pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=16*mm, bottomMargin=16*mm)
    story = [Paragraph("SCAMSHIELD INDIA", styles["CenterTitle"]),
             Paragraph("Cyber Scam Incident Report", styles["Heading2"]),
             Paragraph("Demo report generated by ScamShield India. This is not an official government complaint acknowledgement.", styles["Small"]),
             Spacer(1, 8*mm)]
    def safe(x):
        return str(x if x not in (None, "") else "Not provided").replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\n","<br/>")
    rows = [
        ["Reference number", row["reference"]], ["Created at", row["created_at"]],
        ["Record status", row["status"]], ["Complainant name", row["full_name"]],
        ["Contact phone", row["phone"]], ["Email", row["email"]],
        ["Scam category", row["scam_type"]], ["Incident date", row["incident_date"]],
        ["Amount involved (INR)", row["amount"]], ["Channel / platform", row["channel"]],
        ["Suspect phone / URL / UPI ID", row["suspect_detail"]], ["Transaction ID", row["transaction_id"]],
        ["Incident description", row["description"]], ["Evidence notes", row["evidence_notes"]],
    ]
    data = [[Paragraph(f"<b>{safe(k)}</b>", styles["BodyText"]), Paragraph(safe(v), styles["BodyText"])] for k,v in rows]
    table = Table(data, colWidths=[48*mm, 118*mm], repeatRows=0, hAlign="LEFT")
    table.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(0,-1),colors.HexColor("#eaf0f8")), ("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#cbd5e1")),
        ("VALIGN",(0,0),(-1,-1),"TOP"), ("LEFTPADDING",(0,0),(-1,-1),7), ("RIGHTPADDING",(0,0),(-1,-1),7),
        ("TOPPADDING",(0,0),(-1,-1),6), ("BOTTOMPADDING",(0,0),(-1,-1),6)
    ]))
    story += [table, Spacer(1, 8*mm), Paragraph("<b>Safety next steps</b>", styles["Heading3"]),
              Paragraph("If money was lost in India, contact your bank/payment provider immediately and report financial cyber fraud at 1930 as soon as possible. Use the official National Cyber Crime Reporting Portal at cybercrime.gov.in to submit an official report. Preserve screenshots and transaction references. Never share OTPs, UPI PINs or passwords.", styles["BodyText"]),
              Spacer(1, 5*mm), Paragraph("ScamShield screening and this PDF do not establish guilt or verify the allegation. Keep the reference number private.", styles["Small"])]
    doc.build(story)
    return FileResponse(out, media_type="application/pdf", filename=f"ScamShield_{reference}.pdf")

@app.get("/api/flagged-numbers")
def get_flagged_numbers():
    with db() as conn:
        rows = conn.execute("SELECT phone,label,reason,created_at FROM flagged_numbers ORDER BY id DESC").fetchall()
    return {"numbers": [dict(r) for r in rows]}

@app.post("/api/flagged-numbers")
def add_flagged_number(payload: FlagNumberIn):
    phone = re.sub(r"[^\d+]", "", payload.phone)
    if len(re.sub(r"\D", "", phone)) < 7:
        raise HTTPException(400, "Enter a valid phone number.")
    with db() as conn:
        try:
            conn.execute("INSERT INTO flagged_numbers(phone,label,reason,created_at) VALUES (?,?,?,?)",
                         (phone, payload.label or "Suspected spam", payload.reason or "", datetime.now().astimezone().isoformat(timespec="seconds")))
        except sqlite3.IntegrityError:
            conn.execute("UPDATE flagged_numbers SET label=?,reason=? WHERE phone=?", (payload.label, payload.reason, phone))
    return {"ok": True, "phone": phone, "note": "Added to ScamShield's warning list; this does not block calls at operating-system level."}

@app.delete("/api/flagged-numbers/{phone}")
def remove_flagged_number(phone: str):
    with db() as conn:
        conn.execute("DELETE FROM flagged_numbers WHERE phone=?", (phone,))
    return {"ok": True}
